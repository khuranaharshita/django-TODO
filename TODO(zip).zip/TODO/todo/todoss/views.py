from django.shortcuts import render, get_object_or_404, redirect
from django.views import generic
from .models import Task
from django.http import HttpResponseRedirect
from django.views.generic.list import ListView


def index(request):
    todo_list=Task.objects.all()
    data={
        'todo_list':todo_list
    }
    return render(request,'tasks/main.html',data)

class listview(ListView):
    model=Task()
def add(request):
    title = request.POST['title']
    tasksave=Task(
        title=title)
    tasksave.save() 
    return redirect('tasks:main')
def delete(request, todo_id):
    todo = get_object_or_404(Task, pk=todo_id)
    todo.delete()
    return redirect('tasks:main')
    
def update(request, todo_id):
    todo = get_object_or_404(Task, pk=todo_id)
    isCompleted = request.POST.get('isCompleted', False)
    if isCompleted == 'on':
        isCompleted = True
    
    todo.isCompleted = isCompleted

    todo.save()
    return redirect('tasks:main')


